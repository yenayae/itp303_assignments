function toggleRegistration() {
    document.querySelector(".signup").classList.toggle("hidden");
    document.querySelector(".login").classList.toggle("hidden");
}