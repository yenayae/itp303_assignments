<?php

    
        setcookie("userid", 0, time() + (86400 * 30), "/");
        echo "logout";



 

    


?>